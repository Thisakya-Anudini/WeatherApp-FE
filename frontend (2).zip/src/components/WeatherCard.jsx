import React from 'react';
import { IoIosCloudy, IoIosRainy, IoIosCloud } from "react-icons/io"; // Weather icons

function WeatherCard({ weather }) {
  // Define background color based on weather conditions
  const weatherColor = {
    'clear sky': 'bg-gradient-to-r from-green-400 to-green-600',   // Green for Clear Sky
    'few clouds': 'bg-gradient-to-r from-yellow-500 to-yellow-700', // Yellow for Few Clouds
    'broken clouds': 'bg-gradient-to-r from-purple-500 to-indigo-600', // Purple for Broken Clouds
    'light rain': 'bg-gradient-to-r from-teal-400 to-teal-500',    // Teal for Light Rain
    'mist': 'bg-gradient-to-r from-red-400 to-red-500',           // Red for Mist
  };

  // Determine the icon based on the weather condition
  const getWeatherIcon = (weatherCondition) => {
    switch (weatherCondition.toLowerCase()) {
      case 'clear sky':
        return <IoIosSunny className="text-white w-10 h-10" />;
      case 'few clouds':
        return <IoIosCloudy className="text-white w-10 h-10" />;
      case 'broken clouds':
        return <IoIosCloud className="text-white w-10 h-10" />;
      case 'light rain':
        return <IoIosRainy className="text-white w-10 h-10" />;
      default:
        return <IoIosCloudy className="text-white w-10 h-10" />;
    }
  };

  return (
    <div className={"w-[320px] h-[200px] bg-gray-800 shadow-lg rounded-md overflow-hidden  flex flex-col" }>
      
      {/* Upper part of the card */}
      <div className=" w-[320px] h-[130px] flex justify-between items-start bg-yellow-500 p-3">
        {/* Left side: City and Weather Condition */}
        <div className="flex flex-col items-start w-2/3">
          <h2 className="text-2xl font-bold text-white">{weather.city}</h2> {/* City and Country */}

          <p className="text-md text-white mt-2">{weather.weather}</p> {/* Weather condition */}
        </div>

        {/* Right side: Temperature*/}
        <div className="flex flex-col  w-2/3 items-center">
          <p className="text-4xl mt-5 font-semibold text-white">{weather.temperature} °C</p>
       
        </div>
      </div>



      {/* Lower part of the card */}
      <div className="flex justify-between text-white bg-gray-800 w-[320px] h-[70px] p-1">
        {/* Left section: Pressure, Humidity, and Visibility */}
        <div className="flex flex-col items-center w-1/2 text-xs justify-center">

          <p>Humidity: {weather.humidity || 'N/A'} %</p>

        </div>
        {/* Middle section: Wind Speed with Icon */}
        <div className="flex flex-col items-center w-1/2 text-sm justify-center">
          <p>Wind Speed: {weather.windSpeed || 'N/A'} m/s</p>

        </div>

      </div>
    </div>
  );
}

export default WeatherCard;
