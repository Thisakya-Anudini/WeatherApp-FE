import React from 'react';
import { useLocation, Link } from 'react-router-dom';
import { IoIosArrowBack } from "react-icons/io";
import { IoIosPartlySunny } from "react-icons/io";
import { IoIosCloudy } from "react-icons/io";

function WeatherDetails() {
  const location = useLocation();
  const weatherDetail = location.state?.weatherData;

  if (!weatherDetail) {
    return (
      <div className="min-h-screen bg-[url(./1.jpg)] bg-cover bg-center flex flex-col items-center p-6">
        <div>Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[url(./1.jpg)] bg-cover bg-center flex flex-col items-center p-6">
      <h1 className="text-2xl font-bold text-white mt-8 flex items-center justify-center">
        <IoIosPartlySunny className="w-10 h-10 mr-4 text-purple-500" />
        Weather App
      </h1>

      <div className="w-[600px] h-[350px] bg-gray-800 shadow-lg rounded-md overflow-hidden flex flex-col relative mt-8">
        {/* Back Button with z-index to bring it to the front */}
        <div className="absolute left-0 top-0 z-10">
          <Link to="/" className="text-white mt-6 flex items-center justify-center text-lg">
            <IoIosArrowBack className="mr-2" />
            
          </Link>
        </div>

        {/* Upper part of the card */}
        <div className="w-[600px] h-[250px] flex flex-col justify-center items-center bg-yellow-500 p-8 relative ">

            <h2 className="text-6xl font-bold text-white">{weatherDetail.city}</h2> {/* City and Country */}

      
            <div className="flex flex-row items-center justify-between gap-30 mt-10">
           
              <div>
              <p className="text-md text-white mt-5">{weatherDetail.weather}</p> {/* Weather condition */}
              <IoIosCloudy className="text-white w-10 h-10 mx-5" />
              </div>

              <p className="text-5xl font-bold text-white">{weatherDetail.temperature}°C</p>
              
        </div>
          





        </div>

        {/* Lower part of the card */}
        <div className="flex justify-between text-white bg-gray-800 w-[600px] h-[150px] p-2">
          {/* Left section: Pressure, Humidity, and Visibility */}
          <div className="flex flex-col items-center justify-center w-1/2 text-sm">

            <p>Humidity: {weatherDetail.humidity || 'N/A'} %</p>

          </div>
          {/* Middle section: Wind Speed with Icon */}
          <div className="flex flex-col items-center w-1/2 text-sm justify-center">

            <p>Wind Speed: {weatherDetail.windSpeed || 'N/A'} m/s</p>

          </div>

        </div>
      </div>

      <footer className="w-full bg-gray-800 text-center text-white py-4 absolute bottom-0">
        <p>2025 Fidenz Technologies</p>
      </footer>
    </div>
  );
}

export default WeatherDetails;
